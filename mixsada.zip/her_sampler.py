import sys
import numpy as np
from ray.rllib.models.model import _unpack_obs
from ray.rllib.evaluation.sample_batch import DEFAULT_POLICY_ID
from scipy.stats import rankdata
from collections import defaultdict, OrderedDict
import tensorflow as tf
from ray.rllib.utils.compression import unpack_if_needed


def make_sample_her_transitions(replay_strategy, replay_k, obs_space, reward_fun, obs_filters, preprocessors):

    if replay_strategy == 'future':
        future_p = 1 - (1. / (1 + replay_k))
    else:  # 'replay_strategy' == 'none'
        future_p = 0

    def _sample_her_transitions(episode_batch, batch_size_in_transitions):
        """episode_batch is {array(dicts), each element is an episode )}
        """
        # this code is revised assuming that episode_batch is a dict with lists as value

        print('Started using  HER sampler')

        n_steps = 2

        # make a copy for the replay buffer
        #batches = episode_batch.copy()
        batches  = episode_batch
        # this should be moved
        T = [ batch.count for batch in batches[ 'data' ] ]
        T = np.array(T)
        episodes_size = len(batches[ 'data' ])

        batch_size = batch_size_in_transitions
        her_indexes = np.where(np.random.uniform(size=batch_size) < future_p)[0]
        # these arrays contain a numpy array equivalent to the achieved goals for multi steps
        #print("3ada")
        # adjusted the space because new achieved goal is a box with shape equal to the shape
        # of the contained elements (5x5)
        # the ag_n_steps shape should be (batch_size, n_steps, dimension of the achieved goal)
        # changed from list to appropriate list in order to
        ag_n_steps = np.full([ batch_size, n_steps, obs_space[ "achieved" ].shape[ -1 ] ], np.nan)
        # print(ag_n_steps.shape)

        # Select which episodes and time steps to use.
        # we now have energy representing the episode, we should adjust them to a normal scale
        # and sample episodes from them
        # note to be implemented: move the sampling of episodes to replay buffer
        # change np array because each element inside e_s is a numpy array itself

        # assuming shape of (size,)
        try:
            episode_idxs_energy = np.random.choice(episodes_size, size=batch_size, replace=True)
        except Exception as e:
            print(e)
        episode_idxs = episode_idxs_energy
        t_samples = np.random.uniform(high=T[ episode_idxs_energy ]).astype('int')
        transitions = []

        for i, (e_id, t) in enumerate(zip(episode_idxs, t_samples)):

            transitions.append(batches[ 'data' ][ e_id ].slice(t, t + 1).copy())
            # until and not including
            limit = min(T[ e_id ], t + n_steps)

            # no +1 because portion is not including
            # equivalent to number of valid steps
            portion = min(n_steps, T[ e_id ] - t)
            # should be made in sample batch that dict obs space are defined with sub level is key and lowest level is
            # sample itself

            # this way we get the achieved goals of the next time steps as reward is in form of
            # multi step returns
            # ag_n_steps carries for each sample the achieved goals for n-steps for example if
            # n_steps= n we get ag of new obs for [step t,... , step t+n-1]
            # equivalent to [AG t+1, ... AG t+ n]

            tran_multistep = batches[ 'data' ][ e_id ].slice(t, limit).copy()
            tran_multistep.decompress_if_needed()
            new_obs_multistep = tran_multistep[ 'new_obs' ]
            new_obs_multistep = _unpack_obs(new_obs_multistep, obs_space, tensorlib=np)
            ag_n_steps[ i, :portion ] = new_obs_multistep[ 'achieved' ]

        # creating a SampleBatch object containing the transitions 
        transitions = np.array(transitions)  # check with compressions
        transitions = transitions[ 0 ].concat_samples(transitions)  # Quest hya dy btact 3la np.array wla list?
        #print(transitions)
        transitions.decompress_if_needed()
        #print(transitions)
        #print("ag_n_steps ", ag_n_steps)
        obs_unpacked = _unpack_obs(transitions[ 'obs' ], obs_space,
                                   tensorlib=np)  # Quest hya unpack bta5od concatenated w btrg3o b indexes kaman?
        #print(obs_unpacked['image'].shape)

        future_offset = np.random.uniform(size=batch_size) * (
                    T[ episode_idxs_energy ] - t_samples - 1)  ##Quest hwa T w t_samples nfs l size 3shan t3mlhom minus?
        future_offset = future_offset.astype(int)
        future_t = (t_samples + future_offset)[ her_indexes ] #add clipping and check the +1

        # Replace goal with achieved goal but only for the previously-selected
        # HER transitions (as defined by her_indexes). For the other transitions,
        # keep the original goal. 
        future_ag = [ ]
        #print("Size of a compressed episode ",sys.getsizeof(batches['data'][1]))
        try:
            #print("Start block 1")
            #print("e_id" + str(zip(episode_idxs[ her_indexes ], future_t)))
            for e_id, t in zip(episode_idxs[ her_indexes ], future_t):
                # responded to question and changed the t to be after _unpacking
                batches_copy = batches[ 'data' ][ e_id ].copy()
                (batches_copy).decompress_if_needed()
                unp_new_obs = batches_copy['new_obs']
                ##print(batches[ 'data' ][ e_id ]['new_obs'].shape)
                #unp_new_obs = batches[ 'data' ][ e_id ][ 'new_obs' ]
                unp_new_obs = _unpack_obs(unp_new_obs, obs_space, tensorlib=np)
                # unp_obs = _unpack_obs(batches['data'][e_id]['obs'], obs_space)  #quest hwa 3ady taccess one timestep mn abl mt3ml l unpack
                future_ag.append(unp_new_obs[ 'achieved' ][ t, batches[ 'obj' ][ e_id ]])
            future_ag = np.array(future_ag)
            obs_unpacked[ 'desired' ][ her_indexes ] = future_ag
            #print("End of block 1: No errors")
        except:
            print("Error in block1")

        # observations are returned with modified desired goals
        # preprocessor works only for single sample
        # prep_obs = preprocessors[DEFAULT_POLICY_ID].transform(obs_unpacked)
        # filtered_obs = obs_filters[DEFAULT_POLICY_ID](prep_obs)
        try:
            obs_list = [ ]
            for her_id in her_indexes: ## fixed this: 3ashan the ob_unpacked returned was the keys, not the observation, # refixed this changed the episode_size to batch_size
                #raw_obs = OrderedDict()
                #print(her_id)
                raw_obs = dict()
                for k in obs_unpacked:
                    raw_obs[k] = obs_unpacked[k][her_id]
                    #print(raw_obs[k].shape)
                
                prep_obs = preprocessors.transform(raw_obs) # transfrom only processes a single obs at at time, lesa feeh error fel line dah, try to use get_preprocessor badal preprocessor[Default id]
                #print(prep_obs.shape)
                obs_list.append(prep_obs) #obs_filters[ DEFAULT_POLICY_ID ](prep_obs)

            #filtered_obs = np.array(filtered_obs) #why this is 
            transitions[ 'obs' ][ her_indexes ] = obs_list
            #print("End of block 3")
        except Exception as e:
            print("Error in block 3") #, e)
        #      rewards_multistep[her_indexes]=0  #eh lzmt da w est5dmna feen reward multisteps dy
        try:
            reward_params = {}
            print(ag_n_steps[her_indexes].shape)
            reward_params['desired'] = obs_unpacked[ 'desired' ][ her_indexes ]
            reward_params['achieved'] = ag_n_steps[her_indexes]
            rewards_new = reward_fun(**reward_params)
            rewards_new = np.nan_to_num(rewards_new)
            gamma = 0.99
            gamma_terms = np.array([ gamma ** i for i in range(n_steps) ])
            rewards_total = np.sum(rewards_new * gamma_terms, axis=1)
            transitions[ "rewards" ][ her_indexes ] = rewards_total
            #print("End of block 4")
        except Exception as e:
            print("Error in block 4", e)

        print('EXIT HER sampler')
        return transitions, episode_idxs

    return _sample_her_transitions
