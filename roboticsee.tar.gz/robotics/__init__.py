from gym.envs.robotics.fetch_env import FetchEnv
from gym.envs.robotics.fetch.pick_and_place import FetchPickAndPlaceEnv

