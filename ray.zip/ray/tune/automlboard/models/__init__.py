default_app_config = "ray.tune.automlboard.models.apps.ModelConfig"
