raise DeprecationWarning("Pandas on Ray has moved to Modin: "
                         "github.com/modin-project/modin")
