from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from ray.rllib.env.external_env import ExternalEnv

# renamed to ExternalEnv in 0.6
ServingEnv = ExternalEnv
