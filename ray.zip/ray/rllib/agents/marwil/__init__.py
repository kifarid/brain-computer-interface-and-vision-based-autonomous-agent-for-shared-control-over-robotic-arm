from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from ray.rllib.agents.marwil.marwil import MARWILTrainer, DEFAULT_CONFIG

__all__ = ["MARWILTrainer", "DEFAULT_CONFIG"]
