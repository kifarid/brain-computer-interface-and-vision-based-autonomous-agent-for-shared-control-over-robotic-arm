import numpy as np
from ray.rllib.models.model import _unpack_obs
from ray.rllib.evaluation.sample_batch import DEFAULT_POLICY_ID
from scipy.stats import rankdata

def make_sample_her_transitions(replay_strategy, replay_k, obs_space ,reward_fun, obs_filters, preprocessors):
    """Creates a sample function that can be used for HER experience replay.
    Args:
        replay_strategy (in ['future', 'none']): the HER replay strategy; if set to 'none',
            regular DDPG experience replay is used
        replay_k (int): the ratio between HER replays and regular replays (e.g. k = 4 -> 4 times
            as many HER replays as regular replays are used)
        reward_fun (function): function to re-compute the reward with substituted goals
    """
    if replay_strategy == 'future':
        future_p = 1 - (1. / (1 + replay_k))
    else:  # 'replay_strategy' == 'none'
        future_p = 0

    def _sample_her_transitions(episode_batch, batch_size_in_transitions):
        """episode_batch is {array(dicts), each element is an episode )}
        """
        #this code is revised assuming that episode_batch is a dict with lists as value


        print('started using  HER sampler')

        n_steps = 1

        #make a copy for the replay buffer
        batches=episode_batch.copy()

        # this should be moved
        T = [batch.count for batch in batches['data']]

        episodes_size = len(batches['data'])


        batch_size = batch_size_in_transitions
        her_indexes = np.where(np.random.uniform(size=batch_size) < future_p)
        #these arrays contain a numpy array equivalent to the achieved goals for multi steps

        # adjusted the space because new achieved goal is a box with shape equal to the shape
        # of the contained elements (5x5)
        # the ag_n_steps shape should be (batch_size, n_steps, dimension of the achieved goal)
        ag_n_steps = np.full([batch_size, n_steps] + list(obs_space["achieved"].shape[-1]), np.nan)
        print(ag_n_steps.shape)

        # Select which episodes and time steps to use.
        # we now have energy representing the episode, we should adjust them to a normal scale
        # and sample episodes from them
        # note to be implemented: move the sampling of episodes to replay buffer
        # change np array because each element inside e_s is a numpy array itself

        #assuming shape of (size,)
        energy_total = np.array(batches["e_s"])

        rank = True
        if rank:

            energy_traj_rank = rankdata(energy_total, method='dense')
            energy_traj_rank = energy_traj_rank - 1
            #energy_traj_rank = energy_traj_rank.reshape(-1, 1)

            energy_traj_rank = energy_traj_rank/energy_traj_rank.sum()
            p_trajectory = energy_traj_rank
            # p_trajectory = np.power(energy_traj_rank, 1 / (temperature + 1e-2))

            #natega b3d a5er result di hatkon (#obj,)

        else:
            # energy_total = np.power(energy_total, 1 / (temperature + 1e-2))
            energy_prob = softmax(energy_total)
            p_trajectory = energy_prob

        episode_idxs_energy = np.random.choice(episodes_size, size=batch_size, replace=True,
                                               p=p_trajectory)#.flatten())
        episode_idxs = episode_idxs_energy

        #rewards_multistep = np.zeros(batch_size,n_steps)
        t_samples=np.random.uniform(high=T).astype('int')

        #changed to episodes_size rather than batch_size
        t_samples_indexes = np.random.choice(range(episodes_size), batch_size)
        t_samples=t_samples[t_samples_indexes]

        transitions = []

        for i, (e_id, t) in enumerate(zip(episode_idxs, t_samples)):

            transitions.append(batches['data'][e_id].slice(t, t + 1))

            #until and not including
            limit = min(T[e_id], t + n_steps)

            #no +1 because portion is not including
            # equivalent to number of valid steps
            portion = min(n_steps, T[e_id]-t)
            # should be made in sample batch that dict obs space are defined with sub level is key and lowest level is
            # sample itself

            # this way we get the achieved goals of the next time steps as reward is in form of
            # multi step returns
            # ag_n_steps carries for each sample the achieved goals for n-steps for example if
            # n_steps= n we get ag of new obs for [step t,... , step t+n-1]
            # equivalent to [AG t+1, ... AG t+ n]

            tran_multistep = batches['data'][e_id].slice(t, min(limit+1, T[e_id]))
            #tran_multistep_ag = batches[ e_id ].slice(min(t+1,T[e_id]), min(limit+1,T[e_id]))
            obs_multistep = tran_multistep['obs']
            new_obs_missing = tran_multistep[ 'new_obs' ]
            obs_multistep = _unpack_obs(obs_multistep, obs_space)

            if limit+1 <= T[e_id]:
                
                #choose the object in the selected in this episode 

                ag_n_steps[i, :portion] =obs_multistep['achieved'][1:, batches['obj'][e_id]]     ##ya a3ma
                #rewards_multistep[i, :portion] = tran_multistep["rewards"][:-1]
            else:

                new_obs_missing = tran_multistep[ 'new_obs' ]
                new_obs_missing = _unpack_obs(new_obs_missing, obs_space)
                ag_missing = new_obs_missing['achieved'][T[e_id]-1, batches['obj'][e_id]]
                ag_n_steps[i, :portion] = np.append(obs_multistep[ 'achieved' ][ 1:,
                                                      batches['obj'][e_id]], ag_missing)  ##ya a3ma
                #rewards_multistep[ i, :portion ] = tran_multistep[ "rewards" ] #ya a3ma

        print(ag_n_steps)

        # creating a SampleBatch object containing the transitions
        transitions = np.array(transitions) #check with compressions
        transitions = transitions[0].concat_samples(transitions) #Quest hya dy btact 3la np.array wla list?

        # getting the observations in these transitions and unpacking them
        # the new obs unpacked contains the value for the state at S+n and achieved goal at that
        # state which associated with the state s+n-1
        # and the reward stored in that transition would be R1+...+Rn*gamma**n-1
        obs_unpacked = _unpack_obs(transitions['obs'], obs_space)  #Quest hya unpack bta5od concatenated w btrg3o b indexes kaman?
        new_obs_unpacked = _unpack_obs(transitions['new_obs'], obs_space)


        #transitions_unpacked = transitions.copy()
        # Select future time indexes proportional with probability future_p. These
        # will be used for HER replay by substituting in future goals.

        future_offset = np.random.uniform(size=batch_size) * (T[t_samples_indexes] - t_samples)   ##Quest hwa T w t_samples nfs l size 3shan t3mlhom minus?
        future_offset = future_offset.astype(int)
        future_t = (t_samples + 1 + future_offset)[her_indexes]

        # Replace goal with achieved goal but only for the previously-selected
        # HER transitions (as defined by her_indexes). For the other transitions,
        # keep the original goal.

        future_ag= []

        for e_id, t in zip(episode_idxs[her_indexes], future_t):
            #responded to question and changed the t to be after _unpacking
            unp_obs = _unpack_obs(batches['data'][e_id]['obs'], obs_space)  #quest hwa 3ady taccess one timestep mn abl mt3ml l unpack
            future_ag.append(unp_obs['achieved'][t, batches['obj'][e_id]])

        future_ag=np.array(future_ag)
        obs_unpacked['desired'][her_indexes]= future_ag

        # observations are returned with modified desired goals
        # preprocessor works only for single sample  
        # prep_obs = preprocessors[DEFAULT_POLICY_ID].transform(obs_unpacked)
        # filtered_obs = obs_filters[DEFAULT_POLICY_ID](prep_obs)
        filtered_obs = []
        for ob_unpacked in obs_unpacked:
            prep_obs = preprocessors[DEFAULT_POLICY_ID].transform(ob_unpacked)
            filtered_obs.append = obs_filters[DEFAULT_POLICY_ID](prep_obs)

        filtered_obs = np.array(filtered_obs)
        transitions['obs'][her_indexes]=filtered_obs
 #      rewards_multistep[her_indexes]=0  #eh lzmt da w est5dmna feen reward multisteps dy
        reward_params = dict()
        reward_params['desired']= obs_unpacked['desired'][her_indexes]
        reward_params['achieved'] = ag_n_steps[her_indexes]
        rewards_new = reward_fun(**reward_params)
        rewards_new = np.nan_to_num(rewards_new)
        gamma = 0.99
        gamma_terms = np.array([ gamma**i for i in range(len(n_steps))])
        rewards_total = np.sum(rewards_new*gamma_terms, axis=1)
        transitions["rewards"][her_indexes] = rewards_total

        # 1 it's possible that you achieved the goal in one transition and it remains static afterwards
        # 2 this is not possible due to termination of episode at the end of that
        # we need to add a reward of -0.5 for transitions like Qt-opt
        # Re-compute reward since we may have substituted the goal.
        # the goal stored in the new observation and the new observation it self is
        # the

        #reward_params = {k: transitions[ k ][ v ] for k, v in [ ('new_obs', 'achieved_goal'), ('obs', 'goal') ]}

        #for i in range(n_steps):

            #this loop take into consideration the multistep algorithms

            #reward_params = {k: transitions[k][v] for k,v in [('new_obs', 'achieved_goal'), ('obs', 'goal')]}
            #reward_params['step_flag']= future_t-t_samples < 4
            # we need to clip reward as not to exceed 1

        #    transitions["rewards"] = np.clip(transitions["rewards"]+ reward_fun(**reward_params), a_max=1)
        #    reward_params["achieved_goal"]= ag_n_steps[:,i]["achieved_goal"]

        #    assert(transitions['obs'].shape[0] == batch_size_in_transitions)


        #should remove the achieved goal for not causing overhead
        return transitions, episode_idxs

    return _sample_her_transitions
