import sys
import numpy as np
from ray.rllib.models.model import _unpack_obs
from ray.rllib.evaluation.sample_batch import DEFAULT_POLICY_ID
from scipy.stats import rankdata
from collections import defaultdict, OrderedDict
import tensorflow as tf
from ray.rllib.utils.compression import unpack_if_needed


def softmax(vec):
    vec_exp = np.exp(vec)
    return vec_exp / np.sum(vec_exp)


def make_sample_her_transitions(replay_strategy, replay_k, obs_space, reward_fun, obs_filters, preprocessors):
    """Creates a sample function that can be used for HER experience replay.
    Args:
        replay_strategy (in ['future', 'none']): the HER replay strategy; if set to 'none',
            regular DDPG experience replay is used
        replay_k (int): the ratio between HER replays and regular replays (e.g. k = 4 -> 4 times
            as many HER replays as regular replays are used)
        reward_fun (function): function to re-compute the reward with substituted goals
    """
    if replay_strategy == 'future':
        future_p = 1 - (1. / (1 + replay_k))
    else:  # 'replay_strategy' == 'none'
        future_p = 0

    def _sample_her_transitions(episode_batch, batch_size_in_transitions):
        """episode_batch is {array(dicts), each element is an episode )}
        """
        # this code is revised assuming that episode_batch is a dict with lists as value

        print('Started using  HER sampler')

        n_steps = 2

        # make a copy for the replay buffer
        #batches = episode_batch.copy()
        batches  = episode_batch
        # this should be moved
        T = [ batch.count for batch in batches[ 'data' ] ]
        T = np.array(T)
        episodes_size = len(batches[ 'data' ])

        batch_size = batch_size_in_transitions
        # her_indexes = np.where(np.random.uniform(batch_size) < future_p)
        her_indexes = np.where(np.random.uniform(size=batch_size) < future_p)[0]
        # these arrays contain a numpy array equivalent to the achieved goals for multi steps
        #print("3ada")
        # adjusted the space because new achieved goal is a box with shape equal to the shape
        # of the contained elements (5x5)
        # the ag_n_steps shape should be (batch_size, n_steps, dimension of the achieved goal)
        # changed from list to appropriate list in order to
        ag_n_steps = np.full([ batch_size, n_steps, obs_space[ "achieved" ].shape[ -1 ] ], np.nan)
        # print(ag_n_steps.shape)

        # Select which episodes and time steps to use.
        # we now have energy representing the episode, we should adjust them to a normal scale
        # and sample episodes from them
        # note to be implemented: move the sampling of episodes to replay buffer
        # change np array because each element inside e_s is a numpy array itself

        # assuming shape of (size,)
        energy_total = np.array(batches[ "e_s" ])
        try:
            rank = True
            if rank:
                energy_traj_rank = rankdata(energy_total, method='dense')
                #energy_traj_rank = energy_traj_rank - 1

                #energy_traj_rank = energy_traj_rank
                # energy_traj_rank = energy_traj_rank.reshape(-1, 1)

                energy_traj_rank = energy_traj_rank.astype(float) / energy_traj_rank.sum()
                p_trajectory = energy_traj_rank
                # p_trajectory = np.power(energy_traj_rank, 1 / (temperature + 1e-2))
                # natega b3d a5er result di hatkon (#obj,)

            else:
                #energy_total = np.power(energy_total, 1 / (temperature + 1e-2))
                energy_prob = softmax(energy_total)
                p_trajectory = energy_prob
            episode_idxs_energy = np.random.choice(episodes_size, size=batch_size, replace=True,
                                             p=p_trajectory)  # .flatten())
        except Exception as e:
            print(energy_traj_rank)
            print(energy_total)
            assert 1 == 0
        #print("3ada 3ada")
        #episode_idxs_energy = np.random.choice(episodes_size, size=batch_size, replace=True,
        #                                      p=p_trajectory)  # .flatten())
        episode_idxs = episode_idxs_energy
        # rewards_multistep = np.zeros(batch_size,n_steps)
        
        #t_samples_indexes = np.random.choice(episodes_size, size=batch_size)
        t_samples = np.random.uniform(high=T[ episode_idxs_energy ]).astype('int')
        # changed to episodes_size rather than batch_size
        #t_samples = t_samples[ t_samples_indexes ]
        transitions = []

        for i, (e_id, t) in enumerate(zip(episode_idxs, t_samples)):

            transitions.append(batches[ 'data' ][ e_id ].slice(t, t + 1).copy())
            # until and not including
            limit = min(T[ e_id ], t + n_steps)

            # no +1 because portion is not including
            # equivalent to number of valid steps
            portion = min(n_steps, T[ e_id ] - t)
            # should be made in sample batch that dict obs space are defined with sub level is key and lowest level is
            # sample itself

            # this way we get the achieved goals of the next time steps as reward is in form of
            # multi step returns
            # ag_n_steps carries for each sample the achieved goals for n-steps for example if
            # n_steps= n we get ag of new obs for [step t,... , step t+n-1]
            # equivalent to [AG t+1, ... AG t+ n]

            tran_multistep = batches[ 'data' ][ e_id ].slice(t, limit).copy()
            tran_multistep.decompress_if_needed()
            new_obs_multistep = tran_multistep[ 'new_obs' ]
            new_obs_multistep = _unpack_obs(new_obs_multistep, obs_space, tensorlib=np)
            ag_n_steps[ i, :portion ] = new_obs_multistep[ 'achieved' ][:, batches[ 'obj' ][ e_id ] ]
            # #OLDER VERSION failure
            # tran_multistep = batches[ 'data' ][ e_id ].slice(t, min(limit + 1, T[ e_id ]))
            # tran_multistep.decompress_if_needed()
            # #tran_multistep_ag = batches[ e_id ].slice(min(t+1,T[e_id]), min(limit+1,T[e_id]))
            #
            #obs_multistep = tran_multistep[ 'obs' ]
            #new_obs_missing = tran_multistep[ 'new_obs' ]
            # obs_multistep = _unpack_obs(obs_multistep, obs_space, tensorlib=np)
            # if limit + 1 <= T[e_id]:
            #     # choose the object in the selected in this episode
            #     # print(obs_multistep['achieved'][1:, batches['obj'][e_id]].shape)
            #     # print(obs_multistep['achieved'][1:, batches['obj'][e_id]])
            #     # print("check shape 2")
            #     # print(ag_n_steps[i, :portion].shape)
            #     # print(ag_n_steps[i, :portion])
            #     # print("check shape 3")
            #     ag_n_steps[i, :portion] = obs_multistep[ 'achieved' ][ 1:, batches[ 'obj' ][ e_id ] ]  ##ya a3ma
            #     #rewards_multistep[i, :portion] = tran_multistep["rewards"][:-1]
            # else:
            #     print('critical')
            #     new_obs_missing = tran_multistep['new_obs']
            #     new_obs_missing = _unpack_obs(new_obs_missing, obs_space, tensorlib=np)
            #
            #
            #     ag_missing = new_obs_missing['achieved'][ T[ e_id ] - 1, batches[ 'obj' ][ e_id ] ]
            #     ag_n_steps[i, :portion] = np.append(obs_multistep[ 'achieved' ][ 1:,
            #                                           batches[ 'obj' ][ e_id ] ], ag_missing)  ##ya a3ma
            #     # rewards_multistep[ i, :portion ] = tran_multistep[ "rewards" ] #ya a3ma

        # creating a SampleBatch object containing the transitions 
        transitions = np.array(transitions)  # check with compressions
        transitions = transitions[ 0 ].concat_samples(transitions)  # Quest hya dy btact 3la np.array wla list?
        #print(transitions)
        transitions.decompress_if_needed()
        #print(transitions)
        #print("ag_n_steps ", ag_n_steps)
        # getting the observations in these transitions and unpacking them
        # the new obs unpacked contains the value for the state at S+n and achieved goal at that
        # state which associated with the state s+n-1
        # and the reward stored in that transition would be R1+...+Rn*gamma**n-1
        obs_unpacked = _unpack_obs(transitions[ 'obs' ], obs_space,
                                   tensorlib=np)  # Quest hya unpack bta5od concatenated w btrg3o b indexes kaman?
        #print(obs_unpacked['image'].shape)
        #new_obs_unpacked = _unpack_obs(transitions[ 'new_obs' ], obs_space, tensorlib=np)

        # transitions_unpacked = transitions.copy()
        # Select future time indexes proportional with probability future_p. These
        # will be used for HER replay by substituting in future goals.

        future_offset = np.random.uniform(size=batch_size) * (
                    T[ episode_idxs_energy ] - t_samples - 1)  ##Quest hwa T w t_samples nfs l size 3shan t3mlhom minus?
        future_offset = future_offset.astype(int)
        future_t = (t_samples + future_offset)[ her_indexes ] #add clipping and check the +1

        # Replace goal with achieved goal but only for the previously-selected
        # HER transitions (as defined by her_indexes). For the other transitions,
        # keep the original goal. 
        future_ag = [ ]
        #print("Size of a compressed episode ",sys.getsizeof(batches['data'][1]))
        try:
            #print("Start block 1")
            #print("e_id" + str(zip(episode_idxs[ her_indexes ], future_t)))
            for e_id, t in zip(episode_idxs[ her_indexes ], future_t):
                # responded to question and changed the t to be after _unpacking
                batches_copy = batches[ 'data' ][ e_id ].copy()
                (batches_copy).decompress_if_needed()
                unp_new_obs = batches_copy['new_obs']
                #batches[ 'data' ][ e_id ].decompress_if_needed()
                ##print(batches[ 'data' ][ e_id ]['new_obs'].shape)
                #unp_new_obs = batches[ 'data' ][ e_id ][ 'new_obs' ]
                unp_new_obs = _unpack_obs(unp_new_obs, obs_space, tensorlib=np)
                # unp_obs = _unpack_obs(batches['data'][e_id]['obs'], obs_space)  #quest hwa 3ady taccess one timestep mn abl mt3ml l unpack
                future_ag.append(unp_new_obs[ 'achieved' ][ t, batches[ 'obj' ][ e_id ]])
            future_ag = np.array(future_ag)
            obs_unpacked[ 'desired' ][ her_indexes ] = future_ag
            #print("End of block 1: No errors")
        except:
            print("Error in block1")

        # observations are returned with modified desired goals
        # preprocessor works only for single sample
        # prep_obs = preprocessors[DEFAULT_POLICY_ID].transform(obs_unpacked)
        # filtered_obs = obs_filters[DEFAULT_POLICY_ID](prep_obs)
        try:
            obs_list = [ ]
            for her_id in her_indexes: ## fixed this: 3ashan the ob_unpacked returned was the keys, not the observation, # refixed this changed the episode_size to batch_size
                #raw_obs = OrderedDict()
                #print(her_id)
                raw_obs = dict()
                for k in obs_unpacked:
                    raw_obs[k] = obs_unpacked[k][her_id]
                    #print(raw_obs[k].shape)
                
                prep_obs = preprocessors.transform(raw_obs) # transfrom only processes a single obs at at time, lesa feeh error fel line dah, try to use get_preprocessor badal preprocessor[Default id]
                #print(prep_obs.shape)
                obs_list.append(prep_obs) #obs_filters[ DEFAULT_POLICY_ID ](prep_obs)

            #filtered_obs = np.array(filtered_obs) #why this is 
            transitions[ 'obs' ][ her_indexes ] = obs_list
            #print("End of block 3")
        except Exception as e:
            print("Error in block 3") #, e)
        #      rewards_multistep[her_indexes]=0  #eh lzmt da w est5dmna feen reward multisteps dy
        try:
            reward_params = {}
            print(ag_n_steps[her_indexes].shape)
            reward_params['desired'] = obs_unpacked[ 'desired' ][ her_indexes ]
            reward_params['achieved'] = ag_n_steps[her_indexes]
            rewards_new = reward_fun(**reward_params)
            rewards_new = np.nan_to_num(rewards_new)
            gamma = 0.99
            gamma_terms = np.array([ gamma ** i for i in range(n_steps) ])
            rewards_total = np.sum(rewards_new * gamma_terms, axis=1)
            transitions[ "rewards" ][ her_indexes ] = rewards_total
            #print("End of block 4")
        except Exception as e:
            print("Error in block 4", e)
        # 1 it's possible that you achieved the goal in one transition and it remains static afterwards
        # 2 this is not possible due to termination of episode at the end of that
        # we need to add a reward of -0.5 for transitions like Qt-opt
        # Re-compute reward since we may have substituted the goal.
        # the goal stored in the new observation and the new observation it self is
        # the

        # reward_params = {k: transitions[ k ][ v ] for k, v in [ ('new_obs', 'achieved_goal'), ('obs', 'goal') ]}

        # for i in range(n_steps):

        # this loop take into consideration the multistep algorithms

        # reward_params = {k: transitions[k][v] for k,v in [('new_obs', 'achieved_goal'), ('obs', 'goal')]}
        # reward_params['step_flag']= future_t-t_samples < 4
        # we need to clip reward as not to exceed 1

        #    transitions["rewards"] = np.clip(transitions["rewards"]+ reward_fun(**reward_params), a_max=1)
        #    reward_params["achieved_goal"]= ag_n_steps[:,i]["achieved_goal"]

        #    assert(transitions['obs'].shape[0] == batch_size_in_transitions)

        # should remove the achieved goal for not causing overhead
        print('EXIT HER sampler')
        return transitions, episode_idxs

    return _sample_her_transitions
