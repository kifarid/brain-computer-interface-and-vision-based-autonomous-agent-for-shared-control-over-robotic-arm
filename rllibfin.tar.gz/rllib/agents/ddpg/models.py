from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np
import tensorflow as tf
import numpy as np
import tensorflow.contrib.slim as slim
from gym import spaces
from ray.rllib.agents.ddpg.Networks import P_Network
from ray.rllib.agents.ddpg.Networks import Q_Network
from ray.rllib.models.model import Model
from ray.rllib.utils.annotations import override
from ray.rllib.models.catalog import ModelCatalog
from ray.rllib.models.preprocessors import Preprocessor
from ray.rllib.agents.ddpg.ddpg_policy_graph import DDPGPolicyGraph
from ray.rllib.models.misc import normc_initializer

class Q_KOMP(DDPGPolicyGraph):

    @override(DDPGPolicyGraph)
    def _build_q_network(self, inputs, observation_space, action_space, actions):

        observation_space = spaces.Dict(dict(
            desired=spaces.Box(-np.inf, np.inf, shape=(5,), dtype='float32'),
            achieved=spaces.Box(-np.inf, np.inf, shape=(5,5), dtype='float32'),
            state=spaces.Box(-np.inf, np.inf, shape=(8,), dtype='float32'),
            image =spaces.Box(low=0, high=1.1, shape=(200,200,4), dtype='float32')
        ))
        q_net = Q_Network({'obs':inputs,'prev_actions':actions,}, observation_space, action_space, 1, {"free_log_std":False})
        return q_net.outputs, q_net

    @override(DDPGPolicyGraph)
    def _build_p_network(self, inputs, obs_space, action_space):

        observation_space = spaces.Dict(dict(
            desired=spaces.Box(-np.inf, np.inf, shape=(5,), dtype='float32'),
            achieved=spaces.Box(-np.inf, np.inf, shape=(5,5), dtype='float32'),
            state=spaces.Box(-np.inf, np.inf, shape=(8,), dtype='float32'),
            image =spaces.Box(low=0, high=1.1, shape=(200,200,4), dtype='float32')
        ))

        p_net = P_Network({'obs':inputs,}, observation_space, action_space, 5, {"free_log_std":False})
        return p_net.outputs, p_net


